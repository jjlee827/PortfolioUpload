class FootMeasure:
    def __init__(self, feet=0, inches=0):
        self.feet = feet
        self.inches = inches
    def __str__(self):
        if self.inches >= 12:
            added = self.inches // 12
            self.feet += added
            self.inches %= 12
        if self.inches == 0 and self.feet == 0:
            return "0 ft. 0 in."
        elif self.inches == 0:
            return f"{self.feet} ft."
        else:
            return f"{self.feet} ft. {self.inches} in."
    def __add__(self, another):
        if isinstance(another, FootMeasure):
            new_feet = self.feet +another.feet
            new_inches = self.inches + another.inches
            return FootMeasure(new_feet, new_inches)
    def _total_inches(self):
        return self.feet * 12 + self.inches
    def __eq__(self, another):
        return self._total_inches() == another._total_inches()
    def __ne__(self, another):
        return self._total_inches() != another._total_inches()
    def __lt__(self, another):
        return self._total_inches() < another._total_inches()
    def __le__(self, another):
        return self._total_inches() <= another._total_inches()
    def __gt__(self, another):
        return self._total_inches() > another._total_inches()
    def __ge__(self, another):
        return self._total_inches() >= another._total_inches()