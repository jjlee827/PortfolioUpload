from measure import FootMeasure

#test foot measuredisplay
meas0 = FootMeasure()
meas1 = FootMeasure(feet=5, inches=0)
meas2 = FootMeasure(feet=5, inches=3)
meas3 = FootMeasure(inches=68)

print(meas0)
print(meas1)
print(meas2)
print(meas3)

#test foot measure addition
fm1 = FootMeasure(feet=5)
fm2 = FootMeasure(feet=5, inches=0)
fm3 = fm1 + fm2

print(fm1)
print(fm2)
print(fm3)

#test special methods
m1 = FootMeasure(feet=4)
m2 = FootMeasure(feet=4, inches=2)

print(m1 == m2)
print(m1 != m2)
print(m1 > m2)
print(m1 >= m2)
print(m1 < m2)
print(m1 <= m2)
